<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Merchantpayment extends Model
{
    //
}
