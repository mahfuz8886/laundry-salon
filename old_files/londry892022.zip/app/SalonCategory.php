<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalonCategory extends Model {

    protected $guarded = [];

}
