<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalonBooking extends Model
{
    protected $guarded = [];

    public function statusName() {
        return $this->belongsTo(Parceltype::class, 'status', 'id');
    }

    public function customer() {
        return $this->belongsTo(Customer::class);
    }

    public function service() {
        return $this->belongsTo(SalonService::class);
    }

    public function address() {
        return $this->belongsTo(CustomerAddress::class, 'customer_address_id', 'id')->with('division')->with('district')->with('thana');
    }

}
