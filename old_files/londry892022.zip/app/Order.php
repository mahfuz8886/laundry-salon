<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use ReflectionFunctionAbstract;

class Order extends Model
{
    protected $guarded = [];

    public function getAmount() {
        return $this->hasMany(OrderItem::class,'order_id','id');
    }

    public function statusName() {
        return $this->belongsTo(Parceltype::class,'order_status','id');
    }

    public function orderview() {
        return $this->belongsTo(OrderView::class);
    }

}
