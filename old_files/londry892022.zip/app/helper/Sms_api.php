<?php

    Class sendSms{
        
        public function sendSms(){
            
        }
    }

?>