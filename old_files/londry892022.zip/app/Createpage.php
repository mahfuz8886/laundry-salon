<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Createpage extends Model
{
    //
}
