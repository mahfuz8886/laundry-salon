<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeliverymanArea extends Model
{
    protected $guarded = [];
}
