<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeliverymanExperience extends Model
{
    protected $guarded = [];
}
