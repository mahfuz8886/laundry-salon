<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Topbanner extends Model
{
    //
}
