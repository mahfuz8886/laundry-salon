<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CartItem extends Model
{
    protected $guarded = [];

    public function product() {
        return $this->belongsTo(LaundryProduct::class,'product_id','id');
    }

    public function service() {
        return $this->belongsTo(ProductService::class,'service_id', 'id')->with('serviceName');
    }
}
