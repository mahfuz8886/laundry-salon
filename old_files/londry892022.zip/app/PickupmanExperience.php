<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PickupmanExperience extends Model
{
    protected $guarded = [];
}
