<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use ReflectionFunctionAbstract;

class OrderView extends Model
{
    protected $guarded = [];

}
