<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductService extends Model
{
    protected $guarded = [];

    public function product()
    {
        return $this->belongsTo(LaundryProduct::class,'id');
    }

    public function serviceName() {
        return $this->belongsTo(LaundryProductService::class,'laundry_service_id','id');
    }
}
