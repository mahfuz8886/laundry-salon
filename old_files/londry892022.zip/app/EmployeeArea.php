<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeArea extends Model
{
    protected $guarded = [];
}
