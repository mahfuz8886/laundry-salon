<?php


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use App\Department;
class Employe extends Controller
{
   public function add(){
        return "hello";
   }
}
