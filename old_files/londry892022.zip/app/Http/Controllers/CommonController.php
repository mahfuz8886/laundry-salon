<?php

namespace App\Http\Controllers;

use App\Agent;
use App\AgentThana;
use App\Area;
use App\Customer;
use App\Deliveryman;
use App\District;
use App\Merchant;
use App\Parcel;
use App\Pickupman;
use App\ProductService;
use App\Thana;
use Illuminate\Http\Request;

class CommonController extends Controller
{
    public function getAreaAddress(Request $request){
        $address = [];
        if($request->area_id){
            $address = Parcel::where('area_id', $request->area_id)->distinct('delivery_address')->select('delivery_address')->take(200)->get();
        }
        return response()->json($address);
    }

    public function getDivisionDistricts(Request $request){
        $districts = District::orderBy('name')->where('division_id', $request->division_id)->where('status',1)->get();
        return response()->json($districts);
    }
    
    public function getDistrictThanas(Request $request){
        $thanas = Thana::orderBy('name')->where('district_id', $request->district_id)->where('status',1)->get();
        return response()->json($thanas);
    }
    
    public function getDistrictAgents(Request $request){
        $agent_ids = AgentThana::where('district_id', $request->district_id)->distinct('agent_id')->pluck('agent_id');
        $agents = Agent::orderBy('name')->whereIn('id', $agent_ids)->where('status',1)->get();
        return response()->json($agents);
    }
    
    public function getThanaAreas(Request $request){
        $areas = Area::where('thana_id', $request->thana_id)->where('status',1)->get();
        return response()->json($areas);
    }
    
    public function getAgentAreas(Request $request){
        $thana_ids = AgentThana::whereIn('agent_id', $request->agent_id)->distinct('thana_id')->pluck('thana_id');
        $areas = Area::with('thana')->orderBy('name')->whereIn('thana_id', $thana_ids)->where('status',1)->get();
        return response()->json($areas);
    }
    
    public function getThanaDeliverymenPickupman(Request $request){
        $deliverymens = Deliveryman::where('thana_id', $request->thana_id)->where('status',1)->get();
        $pickupmans = Pickupman::where('thana_id', $request->thana_id)->where('status',1)->get();
        $data = [
            'deliverymens' => $deliverymens,
            'pickupmans' => $pickupmans,
        ];
        return response()->json($data);
    }
    
    public function getMerchantDetails(Request $request){
        $data = Merchant::find($request->merchantId);
        return response()->json($data);
    }

    public function getCustomers(Request $request) {
       
        $customers = Customer::where([
            ['status', 1],
            ['customer_type', $request->type]
        ])->get();

        return response()->json($customers);
    }

    public function getServices(Request $request) {

        $services = ProductService::where('laundry_product_id', $request->product_id)->with('serviceName')->get();
        return $services;
    }
}
