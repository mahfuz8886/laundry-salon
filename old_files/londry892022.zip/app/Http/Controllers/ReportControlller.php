<?php

namespace App\Http\Controllers;

use App\Deliveryman;
use App\Merchant;
use App\Parcel;
use App\Parceltype;
use App\Pickupman;
use Illuminate\Http\Request;

class ReportControlller extends Controller
{
    public function merchantBasedParcels(Request $request)
    {
        $per_page = $request->per_page ?? 100;
        $merchants = Merchant::orderBy('firstName')->verify()->where('status', 1)->get();
        $merchant_info = Merchant::find($request->merchant_id);
        $parcel_types = Parceltype::all();
        $parcels = [];
        $total = [];
        $query = Parcel::orderBy('id', 'desc')->with('parcelStatus');
        if ($request->merchant_id) {
            $query->where('merchantId', $request->merchant_id);

            if ($request->start_date && $request->end_date) {
                $query->whereBetween('created_at', [date('Y-m-d', strtotime($request->start_date)), date('Y-m-d', strtotime($request->end_date))]);
            }
            if ($request->status) {
                $query->where('status', $request->status);
            }

            if ($request->trackingCode) {
                $query->where('trackingCode', $request->trackingCode);
            }
            $parcels = $query->get();
            $total = [
                'parcel' => $parcels->count(),
                'cod' => $parcels->whereIn('status', [4, 6, 7, 8])->sum('cod'),
                'delivery_charge' => $parcels->whereIn('status', [4, 6, 7, 8])->sum('deliveryCharge'),
                'cod_charge' => $parcels->whereIn('status', [4, 6, 7, 8])->sum('codCharge'),
                'merchant_amount' => $parcels->whereIn('status', [4, 6, 7, 8])->sum('merchantAmount'),
                'merchant_payable' => $parcels->whereIn('status', [4, 6, 7, 8])->sum('merchantDue'),
                'merchant_paid' => $parcels->whereIn('status', [4, 6, 7, 8])->sum('merchantPaid'),
            ];
        }
        // dd($parcels);
        return view('backEnd.report.merchant_based_parcels', compact('parcels', 'total', 'parcel_types', 'merchant_info', 'merchants'));
    }

    public function pickupmanBasedParcels(Request $request)
    {
        $per_page = $request->per_page ?? 100;
        $pickupmans = Pickupman::orderBy('name')->where('status', 1)->get();
        $pickupman_info = Pickupman::find($request->pickupman_id);
        $parcel_types = Parceltype::all();
        $parcels = [];
        $query = Parcel::orderBy('id', 'desc')->with('parcelStatus');
        if ($request->pickupman_id) {
            $query->where('pickupmanId', $request->pickupman_id);

            if ($request->start_date && $request->end_date) {
                $query->whereBetween('created_at', [date('Y-m-d', strtotime($request->start_date)), date('Y-m-d', strtotime($request->end_date))]);
            }

            if ($request->status) {
                $query->where('status', $request->status);
            }

            if ($request->trackingCode) {
                $query->where('trackingCode', $request->trackingCode);
            }

            $parcels = $query->get();
        }
        // dd($parcels);
        return view('backEnd.report.pickupman_based_parcels', compact('parcels', 'pickupman_info', 'parcel_types', 'pickupmans'));
    }

    public function deliverymanBasedParcels(Request $request)
    {
        $deliverymans = Deliveryman::orderBy('name')->where('status', 1)->get();
        $deliveryman_info = Deliveryman::find($request->deliveryman_id);
        $parcel_types = Parceltype::all();
        $parcels = [];
        $query = Parcel::orderBy('id', 'desc')->with('parcelStatus');
        if ($request->deliveryman_id) {
            $query->where('deliverymanId', $request->deliveryman_id);

            if ($request->start_date && $request->end_date) {
                $query->whereBetween('created_at', [date('Y-m-d', strtotime($request->start_date)), date('Y-m-d', strtotime($request->end_date))]);
            }

            if ($request->status) {
                $query->where('status', $request->status);
            }

            if ($request->trackingCode) {
                $query->where('trackingCode', $request->trackingCode);
            }

            $parcels = $query->get();
        }
        // dd($parcels);
        return view('backEnd.report.deliveryman_based_parcels', compact('parcels', 'deliveryman_info', 'parcel_types', 'deliverymans'));
    }
}
