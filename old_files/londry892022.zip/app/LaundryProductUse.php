<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LaundryProductUse extends Model {

    protected $guarded = [];

}
