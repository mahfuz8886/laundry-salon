<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PickupmanEducation extends Model
{
    protected $guarded = [];
}
