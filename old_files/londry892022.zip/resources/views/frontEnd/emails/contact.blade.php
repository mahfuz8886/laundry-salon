<h3>A New Message From Website Contact</h3>
 <p><b>Name :</b>{{$contact_title}}</p>
 <p><b>Sent Via :</b>{{$contact_email}}</p>
 <b>Visitor says :</b>{{$contact_text}}