@extends('backEnd.layouts.master')
@section('salon_order_section', 'active menu-open')
@section('orders', 'active')
@section('title', 'Orders')

@section('content')
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            
            <div class="card">
                <div class="card-body">
                    @php 
                    $status = App\ParcelType::where('id', $booking->status)->first(); 
                    @endphp
                    <p><span>@lang('common.booking_id'): <b>{{ $booking->id }}</b></span>, <span>@lang('common.status'): <b>{{ $status->title }}</b></span></p>
                    
                    <div class="py-1">
                        
                        <form class="mb-3" action="{{ route('superadmin.salon.orderUpdate', $booking->id) }}" method="post">
                            @csrf
                            @if($booking->status == 1 || ($booking->status != 12 && $booking->status != 9))
                                <a onclick="return confirm('Are you sure want to cancel order?')" class="btn btn-danger btn-sm" href="{{ route('superadmin.salon.ordercancel', $booking->id) }}">@lang('common.cancel')</a>
                            @endif
                            @if($booking->status == 1)
                                <input type="hidden" name="status" value="10">
                                <input type="submit" value="Confirm" class="btn btn-primary btn-sm">
                            @endif

                            @if($booking->status == 10) 
                                <div class="form-row">
                                    <div class="form-group col-md-3">
                                        <label for="">@lang('common.employee')</label>
                                        <select name="employee[]" multiple id="" required class="form-control select2">
                                            <option value="">@lang('common.select')</option>
                                            @php
                                            $employees = App\Employee::where('status', 1)->get();
                                            @endphp
                                            @foreach($employees as $item)
                                            <option  value="{{ $item->id }}">{{ $item->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <input type="hidden" name="status" value="11">
                                <input type="submit" value="Processing" class="btn btn-primary btn-sm">
                            @endif

                            {{-- work complete order --}}
                            @if($booking->status == 11)
                                <input type="hidden" name="status" value="12">
                                {{-- purchase area --}}
                                <p class="mt-3">
                                    <button type="button" onclick="addMoreItem()" class="btn btn-sm btn-success">@lang('common.add_more')</button>
                                </p>
                                <div class="table-responsive">
                                    <table class="table table-striped w-100">
                                        <thead>
                                            <tr>
                                                <th>@lang('common.action')</th>
                                                <th>@lang('common.item')</th>
                                                <th>@lang('common.buy_price')</th>
                                                <th>@lang('common.sale_price')</th>
                                                <th>@lang('common.quantity')</th>
                                            </tr>
                                        </thead>
                                        <tbody class="rowContainer">
                                            <tr>
                                                <td style="min-width: 40px"></td>
                                                <td style="min-width: 200px">
                                                    <select name="item[]" id="item" class="form-control select2" required onchange="getBuyAndSalePrice(this.value, this)">
                                                        @php
                                                        $branches = App\helper\CustomHelper::getUserBranch();
                                                        $items = App\SalonInventoryLog::groupBy('item_id')->selectRaw('sum(quantity) as sum, item_id, branch_id')->where('quantity', '>', 0)
                                                        ->where('in_out', 'In');
                                                        if($branches != null) {
                                                            $items = $items->whereIn('branch_id', $branches);
                                                        }
                                                        $items = $items->with('item')->with('unit')->get();
                                                        @endphp
                                                        <option value="">@lang('common.choose')</option>
                                                        @foreach($items as $item)
                                                        <option value="{{ $item->item_id }},{{ $item->branch_id }}">{{ $item->item->name }} ({{$item->sum}})</option>
                                                        @endforeach
                                                    </select>
                                                </td>
                                                <td style="min-width: 150px"><input type="number" step="any" class="form-control buyPrice" name="buy_price[]" required></td>
                                                <td style="min-width: 150px"><input type="number" step="any" class="form-control saleprice" name="sale_price[]" required></td>
                                                <td style="min-width: 150px"><input type="number" class="form-control quantity" name="quantity[]" required></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <input type="submit" value="Work completed" class="btn btn-primary btn-sm">
                            @endif

                        </form>

                        <p>
                            @if($booking->status != 1)
                            <span>{{$status->title}} on </span><b>@php echo date('F Y h:i:s a',strtotime($booking->updated_at)) @endphp</b>
                            @endif
                        </p>
                    </div>
                    
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-5">
                    <div class="card">
                        <div class="card-body">
                            @php
                            $orderEmps = App\SalonOrderEmployee::where('order_id', $booking->id)->with('employee')->get();
                            @endphp
                            <p class="text-dark">@lang('common.employee_info')</p>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>@lang('common.order_id')</th>
                                            <th>@lang('common.employee')</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($orderEmps as $item)
                                        
                                        <tr>
                                            <td>{{ $item->order_id }}</td>
                                            <td>{{ $item->employee->name }}</td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="2" class="text-center">@lang('common.no_data_found')</td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="text-dark"><b>@lang('common.items')</b></h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>@lang('common.image')</th>
                                            <th>@lang('common.service')</th>
                                            <th>@lang('common.price')</th>
                                            <th>@lang('common.space')</th>
                                            <th>@lang('common.total')</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if($booking && $booking->id)
                                        <tr>
                                            <td>
                                                @php
                                                $category = App\SalonCategory::where('id', $booking->service->category_id)->first();
                                                @endphp
                                                <img style="width: 60px;" class="img-fluid" src="{{ asset($category->image) }}" alt="">
                                            </td>
                                            <td>
                                                {{ $booking->service->service_name }}
                                            </td>
                                            <td>৳{{ $booking->per_space }}</td>
                                            <td>{{ $booking->space }}</td>
                                            <td>৳{{ $booking->space *  $booking->per_space }}</td>
                                        </tr>
                                        @else
                                        <tr>
                                            <td colspan="5" class="text-center">@lang('common.no_data_found')</td>
                                        </tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <p>@lang('common.customer_address')</p>
                            <p class="m-1"><b>{{ $booking->address->fullname??'' }}</b></p>
                            <p class="m-1"><small class="bg-primary rounded p-1">{{ $booking->address->type??'' }}</small><small>{{ $booking->address->address??'' }}, {{ $booking->address->thana->name??'' }}, {{ $booking->address->district->name??'' }}, {{ $booking->address->division->name??'' }}</small></p>
                            <p class="m-1"><small>{{ $booking->address->mobile_no??'' }}</small></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <p><b>@lang('common.summary')</b></p>
                            <div class="d-flex  justify-content-between mb-1">
                                <span>@lang('common.sub_total')</span> <span>৳{{ $booking->space * $booking->per_space }}</span>
                            </div>
                            <div class="d-flex  justify-content-between border-bottom pb-1">
                                <span>@lang('common.discount')</span> <span>৳{{ $booking->discount }}</span>
                            </div>
                            <div class="d-flex  justify-content-between mb-1">
                                <span><b>@lang('common.total')</b></span> <span>৳{{ $booking->space * $booking->per_space - $booking->discount }}</span>
                            </div>
                            <p class="mt-4">@lang('common.paid_by'): <span><b>{{ $booking->payment_method_id==1? 'Cash':'' }}</b></span></p>
                        </div>
                    </div>
                </div>
            </div>

            {{-- template area --}}
        <template>
            <tr>
                <td style="min-width: 40px"><i class="fas fa-trash text-danger" onclick="deleteRow(this)"></i></td>
                <td style="min-width: 200px">
                    <select name="item[]" id="item" class="form-control select2" required onchange="getBuyAndSalePrice(this.value,this)">
                        @php
                        $branches = App\helper\CustomHelper::getUserBranch();
                        $items = App\SalonInventoryLog::groupBy('item_id')->selectRaw('sum(quantity) as sum, item_id, branch_id')->where('quantity', '>', 0)
                        ->where('in_out', 'In');
                                                        if($branches != null) {
                                                            $items = $items->whereIn('branch_id', $branches);
                                                        }
                                                        $items = $items->with('item')->with('unit')->get();
                        @endphp
                        <option value="">@lang('common.choose')</option>
                        @foreach($items as $item)
                        <option value="{{ $item->item_id }},{{ $item->branch_id }}">{{ $item->item->name }} ({{$item->item->sum}})</option>
                        @endforeach
                    </select>
                </td>
                <td style="min-width: 150px"><input type="number" step="any" class="form-control buyPrice" name="buy_price[]" required></td>
                <td style="min-width: 150px"><input type="number" step="any" class="form-control saleprice" name="sale_price[]" required></td>
                <td style="min-width: 150px"><input type="number" class="form-control quantity" name="quantity[]" required></td>
            </tr>
        </template>
        {{-- template area --}}

        </div>
    </section>
@endsection

@section('script')
    <script>
        function addMoreItem() {
          var temp = document.getElementsByTagName("template")[0];
          var clon = temp.content.cloneNode(true);
          document.querySelector('.rowContainer').appendChild(clon);
        }

        function deleteRow(button) {
            let tr = button.closest('tr');
            tr.parentNode.removeChild(tr);
        }

        function getBuyAndSalePrice(item, ref) {
            let itemId = item;
            let buy = $(ref).closest('tr').find('.buyPrice');
            let sale = $(ref).closest('tr').find('.saleprice');
            
            
            if(itemId != null) {
                $.ajax({
                    type: 'POST',
                    url: '{{ route('superadmin.salon.getItemPrices') }}',
                    data: {itemId},
                    success: function(data) {
                        if(data != null) {
                            // console.log(data);
                           buy.val(data.buy_price);
                           sale.val(data.sale_price);
                        }
                    }
                })
            }
        }
    </script>
@endsection